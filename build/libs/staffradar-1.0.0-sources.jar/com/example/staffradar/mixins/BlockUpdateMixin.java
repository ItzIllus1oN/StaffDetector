package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_2626;
import net.minecraft.class_310;
import net.minecraft.class_634;

@Mixin(class_634.class)
public class BlockUpdateMixin {
    // Cooldown map: block pos -> last scored time
    private static final Map<Long, Long> blockCooldowns = new ConcurrentHashMap<>();
    private static final long BLOCK_COOLDOWN_MS = 5000;

    @Inject(method = "onBlockUpdate", at = @At("HEAD"))
    private void onBlockUpdate(class_2626 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().blockEnabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_2338 pos = packet.method_11309();
        double distSq = client.field_1724.method_19538().method_1025(pos.method_46558());
        if (distSq > 64) return; // Within 8 blocks

        // Throttle: don't score the same block position repeatedly
        long key = pos.method_10063();
        long now = System.currentTimeMillis();
        if (blockCooldowns.getOrDefault(key, 0L) + BLOCK_COOLDOWN_MS > now) return;

        boolean playerNearby = client.field_1687.method_18456().stream()
            .anyMatch(p -> !p.equals(client.field_1724) && p.method_19538().method_1025(pos.method_46558()) < 9);

        if (!playerNearby) {
            blockCooldowns.put(key, now);
            StaffRadarMod.LOGGER.info("[StaffRadar] Block update with no visible player nearby at {}. Score +2", pos);
            StaffRadarMod.getInstance().getSpectatorWatcher().addScore("block", 2);
        }
    }
}
