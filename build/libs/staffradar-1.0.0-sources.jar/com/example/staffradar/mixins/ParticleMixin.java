package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_2396;
import net.minecraft.class_2675;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_7923;

@Mixin(class_634.class)
public class ParticleMixin {
    private static final Set<String> SUSPICIOUS_PARTICLES = Set.of(
            "minecraft:sweep_attack",
            "minecraft:crit",
            "minecraft:enchanted_hit",
            "minecraft:soul_fire_flame",
            "minecraft:large_smoke");

    private static long lastParticleScore = 0;
    private static final long PARTICLE_GLOBAL_COOLDOWN_MS = 3000;

    @Inject(method = "onParticle", at = @At("HEAD"))
    private void onParticle(class_2675 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().particleEnabled)
            return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null)
            return;

        long now = System.currentTimeMillis();
        if (now - lastParticleScore < PARTICLE_GLOBAL_COOLDOWN_MS)
            return;

        class_2396<?> type = packet.method_11551().method_10295();
        String particleId = class_7923.field_41180.method_10221(type).toString();
        if (!SUSPICIOUS_PARTICLES.contains(particleId))
            return;

        double distSq = client.field_1724.method_5649(packet.method_11544(), packet.method_11547(), packet.method_11546());
        if (distSq > 64)
            return;

        if (distSq < 6.25)
            return;

        boolean otherPlayerNearby = client.field_1687.method_18456().stream()
                .anyMatch(p -> !p.equals(client.field_1724)
                        && p.method_5649(packet.method_11544(), packet.method_11547(), packet.method_11546()) < 9);

        if (!otherPlayerNearby) {
            lastParticleScore = now;
            StaffRadarMod.LOGGER.info("[StaffRadar] Suspicious particle '{}' with no visible player nearby. Score +3",
                    particleId);
            StaffRadarMod.getInstance().getSpectatorWatcher().addScore("particle", 3);
        }
    }
}
