package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import net.minecraft.class_1297;
import net.minecraft.class_2739;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class EntityTrackerMixin {

    @Inject(method = "onEntityTrackerUpdate", at = @At("HEAD"))
    private void onEntityTrackerUpdate(class_2739 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().invisibleEntityEnabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        // Skip ourselves
        if (packet.comp_1127() == client.field_1724.method_5628()) return;

        class_1297 entity = client.field_1687.method_8469(packet.comp_1127());
        if (entity == null) return;

        // We only care about entities that are visible players
        // If the entity is a player AND is now being tracked as Invisible, that's suspicious
        if (entity instanceof net.minecraft.class_742 playerEntity) {
            if (packet.comp_1128() == null) return;

            packet.comp_1128().forEach(entry -> {
                // DataTracker entry ID 6 = flags byte for LivingEntity
                // Invisible flag = bit 5 (0x20)
                if (entry.comp_1115() == 6) {
                    Object value = entry.comp_1117();
                    if (value instanceof Byte flags) {
                        boolean invisible = (flags & 0x20) != 0;
                        if (invisible) {
                            StaffRadarMod.LOGGER.info("[StaffRadar][!] Entity {} ({}) has INVISIBLE flag set! Score +8", packet.comp_1127(), playerEntity.method_7334().getName());
                            StaffRadarMod.getInstance().getSpectatorWatcher().addScore("invisible_entity", 8);
                        }
                    }
                }
            });
        }
    }
}
