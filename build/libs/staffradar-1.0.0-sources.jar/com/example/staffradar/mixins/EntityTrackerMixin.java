package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_1297;
import net.minecraft.class_2739;
import net.minecraft.class_310;
import net.minecraft.class_634;

@Mixin(class_634.class)
public class EntityTrackerMixin {

    private static final AtomicInteger selfUpdates = new AtomicInteger(0);
    private static final AtomicInteger otherUpdates = new AtomicInteger(0);
    private static long lastSpikeCheck = System.currentTimeMillis();
    private static final long SPIKE_WINDOW_MS = 5000;
    private static final double SPIKE_RATIO_THRESHOLD = 2.5;
    private static final int MIN_OTHER_PACKETS = 5;

    @Inject(method = "onEntityTrackerUpdate", at = @At("HEAD"))
    private void onEntityTrackerUpdate(class_2739 packet, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null)
            return;

        boolean isSelf = packet.comp_1127() == client.field_1724.method_5628();

        if (!isSelf && com.example.staffradar.config.ConfigManager.getConfig().invisibleEntityEnabled) {
            class_1297 entity = client.field_1687.method_8469(packet.comp_1127());
            if (entity instanceof net.minecraft.class_742 playerEntity) {
                if (packet.comp_1128() != null) {
                    packet.comp_1128().forEach(entry -> {
                        if (entry.comp_1115() == 6 && entry.comp_1117() instanceof Byte flags) {
                            if ((flags & 0x20) != 0) {
                                StaffRadarMod.LOGGER.warn("[StaffRadar][INVISIBLE] Player {} has Invisible flag set!",
                                        playerEntity.method_7334().getName());
                                StaffRadarMod.getInstance().getSpectatorWatcher().addScore("invisible_entity", 8);
                            }
                        }
                    });
                }
            }
        }

        if (isSelf) {
            selfUpdates.incrementAndGet();
        } else {
            otherUpdates.incrementAndGet();
        }

        long now = System.currentTimeMillis();
        if (now - lastSpikeCheck >= SPIKE_WINDOW_MS) {
            int self = selfUpdates.getAndSet(0);
            int other = otherUpdates.getAndSet(0);
            lastSpikeCheck = now;

            if (other >= MIN_OTHER_PACKETS && self > other * SPIKE_RATIO_THRESHOLD) {
                StaffRadarMod.LOGGER.warn(
                        "[StaffRadar][SPIKE] Self entity got {} updates vs {} other updates in {}ms — possible spectator watching!",
                        self, other, SPIKE_WINDOW_MS);
                StaffRadarMod.getInstance().getSpectatorWatcher().addScore("entity_spike", 5);
            }
        }
    }
}
