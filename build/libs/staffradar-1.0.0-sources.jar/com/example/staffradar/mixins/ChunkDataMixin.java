package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2672;
import net.minecraft.class_310;
import net.minecraft.class_634;

@Mixin(class_634.class)
public class ChunkDataMixin {
    private static final Set<Long> loadedChunks = ConcurrentHashMap.newKeySet();
    private static long joinTime = 0;
    private static final long GRACE_PERIOD_MS = 15000;

    @Inject(method = "onChunkData", at = @At("HEAD"))
    private void onChunkData(class_2672 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().chunkEnabled)
            return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null)
            return;

        long now = System.currentTimeMillis();

        if (joinTime == 0) {
            joinTime = now;
        }

        if (now - joinTime < GRACE_PERIOD_MS) {
            loadedChunks.add(chunkKey(packet.method_11523(), packet.method_11524()));
            return;
        }

        long key = chunkKey(packet.method_11523(), packet.method_11524());

        if (loadedChunks.contains(key)) {
            int playerChunkX = client.field_1724.method_31476().field_9181;
            int playerChunkZ = client.field_1724.method_31476().field_9180;
            int dx = Math.abs(packet.method_11523() - playerChunkX);
            int dz = Math.abs(packet.method_11524() - playerChunkZ);

            if (dx <= 4 && dz <= 4) {
                double vel = client.field_1724.method_18798().method_1027();
                if (vel < 0.05) {
                    StaffRadarMod.LOGGER.info(
                            "[StaffRadar] Nearby chunk {},{} reloaded while player was still. Score +3",
                            packet.method_11523(), packet.method_11524());
                    StaffRadarMod.getInstance().getSpectatorWatcher().addScore("chunk", 3);
                }
            }
        }

        loadedChunks.add(key);
    }

    private static long chunkKey(int x, int z) {
        return ((long) x << 32) | (z & 0xFFFFFFFFL);
    }
}
