package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class SoundPacketMixin {
    @Inject(method = "onPlaySound", at = @At("HEAD"))
    private void onPlaySound(class_2767 packet, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        double distSq = client.field_1724.method_5649(packet.method_11890(), packet.method_11889(), packet.method_11893());
        if (distSq < 100) { // Within 10 blocks
            // Check if there's a visible player at that location
            boolean playerNearby = client.field_1687.method_18456().stream()
                .anyMatch(p -> p.method_5649(packet.method_11890(), packet.method_11889(), packet.method_11893()) < 4);
            
            if (!playerNearby) {
                String soundId = packet.method_11894().comp_349().comp_3319().toString();
                
                // Blacklist filter
                if (com.example.staffradar.config.ConfigManager.getConfig().soundBlacklist.contains(soundId)) {
                    return;
                }
                
                StaffRadarMod.getInstance().getSpectatorWatcher().addScore("Suspicious Sound (" + soundId + ")", 1);
            }
        }
    }
}
