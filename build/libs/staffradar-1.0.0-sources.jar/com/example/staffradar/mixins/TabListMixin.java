package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import net.minecraft.class_2703;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class TabListMixin {
    @Inject(method = "onPlayerList", at = @At("HEAD"))
    private void onPlayerListUpdate(class_2703 packet, CallbackInfo ci) {
        // StaffRadarMod.getInstance().getStaffDetector().onPlayerListPacket(packet);
        // Logic handled in StaffDetector tick for now, but packet-based update is more efficient
    }
}
