package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import com.example.staffradar.detection.StaffPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2703;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_7828;

@Mixin(class_634.class)
public class VanishTrackerMixin {

    private static final Map<UUID, String> tabListRegistry = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> vanishCooldowns = new ConcurrentHashMap<>();
    private static final long VANISH_COOLDOWN_MS = 15000;

    @Inject(method = "onPlayerList", at = @At("HEAD"))
    private void onPlayerList(class_2703 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().vanishTrackerEnabled)
            return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null)
            return;

        for (class_2703.class_2705 entry : packet.method_46329()) {
            UUID uuid = entry.comp_1106();
            if (uuid.equals(client.field_1724.method_5667()))
                continue;

            if (entry.comp_1107() != null && entry.comp_1107().getName() != null) {
                tabListRegistry.put(uuid, entry.comp_1107().getName());
            }

            if (packet.method_46327().contains(class_2703.class_5893.field_40700)) {
                if (!entry.comp_1108()) {
                    checkVanishEvent(uuid, "UPDATE_LISTED=false (hidden from tab)", client);
                }
            }
        }
    }

    @Inject(method = "onPlayerRemove", at = @At("HEAD"))
    private void onPlayerRemove(class_7828 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().vanishTrackerEnabled)
            return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null)
            return;

        List<UUID> removedUuids = packet.comp_1105();
        for (UUID uuid : removedUuids) {
            if (uuid.equals(client.field_1724.method_5667()))
                continue;
            checkVanishEvent(uuid, "removed from session without disconnect", client);
        }
    }

    private void checkVanishEvent(UUID uuid, String reason, class_310 client) {
        if (!StaffRadarMod.getInstance().getStaffDetector().isKnownStaff(uuid))
            return;

        long now = System.currentTimeMillis();
        if (vanishCooldowns.getOrDefault(uuid, 0L) + VANISH_COOLDOWN_MS > now)
            return;
        vanishCooldowns.put(uuid, now);

        StaffPlayer staff = StaffRadarMod.getInstance().getStaffDetector().getStaffByUuid(uuid);
        String staffName = staff != null ? staff.name() : tabListRegistry.getOrDefault(uuid, uuid.toString());

        String alert = "§4§l⚠ VANISH DETECTED! §r§c" + staffName + " §7(" + reason + ")";
        StaffRadarMod.LOGGER.warn("[StaffRadar][VANISH] {} - {}", staffName, reason);

        if (client.field_1724 != null) {
            client.field_1724.method_7353(net.minecraft.class_2561.method_43470(alert), false);
            client.field_1724.method_7353(net.minecraft.class_2561.method_43470(
                    "§7" + staffName + " §fwas a known staff and disappeared from the tab list."), false);
        }

        StaffRadarMod.getInstance().getSpectatorWatcher().addScore("vanish_detected", 999);
    }
}
