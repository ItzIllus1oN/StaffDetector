package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import net.minecraft.class_2708;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class CameraAberrationMixin {

    @Inject(method = "onPlayerPositionLook", at = @At("HEAD"))
    private void onPlayerPositionLook(class_2708 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().cameraAberrationEnabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        // If the player is essentially standing still and the server sends a forced position correction,
        // this can indicate a spectator teleporting to the player's position triggered a re-sync.
        double velocitySq = client.field_1724.method_18798().method_1027();
        if (velocitySq < 0.005) {
            StaffRadarMod.LOGGER.info("[StaffRadar] Camera Aberration detected! Server forced position while player was still. Score +5");
            StaffRadarMod.getInstance().getSpectatorWatcher().addScore("camera", 5);
        }
    }
}
