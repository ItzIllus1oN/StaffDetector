package com.example.staffradar.mixins;

import com.example.staffradar.StaffRadarMod;
import net.minecraft.class_2708;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class CameraAberrationMixin {
    private static long lastCameraScore = 0;
    private static final long CAMERA_COOLDOWN_MS = 8000;

    @Inject(method = "onPlayerPositionLook", at = @At("HEAD"))
    private void onPlayerPositionLook(class_2708 packet, CallbackInfo ci) {
        if (!com.example.staffradar.config.ConfigManager.getConfig().cameraAberrationEnabled)
            return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null)
            return;

        long now = System.currentTimeMillis();
        if (now - lastCameraScore < CAMERA_COOLDOWN_MS)
            return;

        double vx = client.field_1724.method_18798().field_1352;
        double vy = client.field_1724.method_18798().field_1351;
        double vz = client.field_1724.method_18798().field_1350;

        boolean trulyStill = Math.abs(vx) < 0.005 && Math.abs(vy) < 0.05 && Math.abs(vz) < 0.005;

        if (trulyStill) {
            lastCameraScore = now;
            StaffRadarMod.LOGGER
                    .info("[StaffRadar] Camera Aberration: server forced position while player was still. Score +5");
            StaffRadarMod.getInstance().getSpectatorWatcher().addScore("camera", 5);
        }
    }
}
