package com.example.staffradar.detection;

import com.example.staffradar.StaffRadarMod;
import com.example.staffradar.gui.WatchAlertUI;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_310;
import java.util.Map;

public class SpectatorWatcher {
    private final Map<String, Integer> scores = new ConcurrentHashMap<>();
    private final Map<String, Long> reasonCooldowns = new ConcurrentHashMap<>();
    private long lastAlertTime = 0;
    private static final long COOLDOWN_MS = 10000;
    private static final long REASON_COOLDOWN_MS = 4000;

    public void tick(class_310 client) {
        if (client.field_1724 == null)
            return;

        if (System.currentTimeMillis() % 5000 < 50) {
            scores.entrySet().forEach(entry -> {
                if (entry.getValue() > 0)
                    entry.setValue(entry.getValue() - 1);
            });
            scores.values().removeIf(score -> score <= 0);
        }
    }

    public void addScore(String reason, int amount) {
        com.example.staffradar.config.Config config = com.example.staffradar.config.ConfigManager.getConfig();
        if (reason.contains("sound") && !config.soundEnabled)
            return;
        if (reason.contains("chunk") && !config.chunkEnabled)
            return;
        if (reason.contains("block") && !config.blockEnabled)
            return;
        if (reason.contains("particle") && !config.particleEnabled)
            return;
        if (reason.contains("invisible") && !config.invisibleEntityEnabled)
            return;
        if (reason.contains("camera") && !config.cameraAberrationEnabled)
            return;
        if (reason.contains("vanish") && !config.vanishTrackerEnabled)
            return;
        if (reason.contains("tab_vs_world") && !config.keywordEnabled)
            return;
        if (reason.contains("entity_spike") && !config.invisibleEntityEnabled)
            return;

        long now = System.currentTimeMillis();
        if (reasonCooldowns.getOrDefault(reason, 0L) + REASON_COOLDOWN_MS > now)
            return;
        reasonCooldowns.put(reason, now);

        scores.merge(reason, amount, Integer::sum);
        checkAlert();
    }

    private void checkAlert() {
        int totalScore = scores.values().stream().mapToInt(Integer::intValue).sum();
        long now = System.currentTimeMillis();
        float threshold = com.example.staffradar.config.ConfigManager.getConfig().threshold;

        if (totalScore >= threshold && (now - lastAlertTime > COOLDOWN_MS)) {
            if (com.example.staffradar.config.ConfigManager.getConfig().spectatorAlertEnabled) {
                triggerAlert();
                lastAlertTime = now;
            }
            scores.clear();
        }
    }

    private void triggerAlert() {
        class_310 client = class_310.method_1551();
        StringBuilder debugInfo = new StringBuilder("⚠ STAFF IS WATCHING YOU ⚠ Details: ");
        scores.forEach((reason, score) -> debugInfo.append("[").append(reason).append(": ").append(score).append("] "));

        String logMsg = debugInfo.toString();

        if (client.field_1724 != null) {
            client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§4§l⚠ STAFF IS WATCHING YOU ⚠"), true);
            client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§c" + logMsg), false);
        }

        StaffRadarMod.LOGGER.info(logMsg);
        WatchAlertUI.show();
    }

    public void resetScores() {
        scores.clear();
    }
}
