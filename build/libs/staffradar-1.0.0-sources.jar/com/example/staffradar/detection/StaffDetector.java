package com.example.staffradar.detection;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_310;
import net.minecraft.class_640;

public class StaffDetector {
    private final Map<UUID, StaffPlayer> detectedStaff = new ConcurrentHashMap<>();
    private int tickCounter = 0;

    public void tick(class_310 client) {
        if (tickCounter++ % 20 != 0) return; // Scan every 1 second

        if (client.method_1562() == null || !com.example.staffradar.config.ConfigManager.getConfig().keywordEnabled) {
            detectedStaff.clear();
            return;
        }

        List<String> keywords = com.example.staffradar.config.ConfigManager.getConfig().keywords;
        Collection<class_640> playerList = client.method_1562().method_2880();
        Set<UUID> currentUuids = new HashSet<>();

        for (class_640 entry : playerList) {
            UUID uuid = entry.method_2966().getId();
            
            // Intelligence: Don't detect local player as staff
            if (client.field_1724 != null && uuid.equals(client.field_1724.method_5667())) continue;

            String name = entry.method_2966().getName();
            if (name == null || name.trim().isEmpty()) continue; // Skip entries without valid names

            String displayName = entry.method_2971() != null ? entry.method_2971().getString() : "";
            
            // Keyword check in name and display name with "Strict Word Boundary" matching
            for (String keyword : keywords) {
                if (keyword == null || keyword.trim().isEmpty()) continue;
                // Use Regex for strict matching
                String k = keyword.trim();
                
                if (isStaffMatch(name, k) || isStaffMatch(displayName, k)) {
                    addStaff(uuid, name, "Keyword: " + keyword);
                    currentUuids.add(uuid);
                    break;
                }
            }
        }

        // Cleanup players who left or are no longer "staff"
        detectedStaff.keySet().removeIf(uuid -> !currentUuids.contains(uuid) && (System.currentTimeMillis() - detectedStaff.get(uuid).discoveryTime() > 10000));
        
        // Refresh UI
        com.example.staffradar.gui.StaffOverlayUI.updateList(detectedStaff.values());
    }

    public void addStaff(UUID uuid, String name, String reason) {
        if (!detectedStaff.containsKey(uuid)) {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null) {
                client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§c[StaffRadar] §6" + name + " §fdetected in §eTab list!"), false);
            }
        }
        detectedStaff.put(uuid, new StaffPlayer(uuid, name, reason, System.currentTimeMillis()));
    }

    public Collection<StaffPlayer> getDetectedStaff() {
        return detectedStaff.values();
    }

    private boolean isStaffMatch(String text, String keyword) {
        if (text == null || keyword == null || keyword.isEmpty()) return false;
        
        String strippedText = stripFormatting(text);
        String strippedK = stripFormatting(keyword);
        
        if (strippedK.isEmpty()) return false;

        // Search for all occurrences of strippedK in strippedText
        String textLower = strippedText.toLowerCase();
        String kLower = strippedK.toLowerCase();
        
        int index = textLower.indexOf(kLower);
        while (index != -1) {
            // Check boundaries in the STRIPPED text
            // Before match
            boolean beforeOk = true;
            if (index > 0) {
                char before = strippedText.charAt(index - 1);
                if (Character.isLetterOrDigit(before)) beforeOk = false;
            }
            
            // After match
            boolean afterOk = true;
            if (index + strippedK.length() < strippedText.length()) {
                char after = strippedText.charAt(index + strippedK.length());
                if (Character.isLetterOrDigit(after)) afterOk = false;
            }
            
            if (beforeOk && afterOk) return true;
            
            index = textLower.indexOf(kLower, index + 1);
        }
        
        return false;
    }

    private String stripFormatting(String input) {
        if (input == null) return "";
        // 1. Strip hex colors: &x or §x followed by 6 pairs of §c or &c
        String stripped = input.replaceAll("(?i)[§&]x([§&][0-9a-f]){6}", "");
        // 2. Strip normal color codes and formatting
        return stripped.replaceAll("(?i)[§&][0-9a-fk-orx]", "");
    }

}
