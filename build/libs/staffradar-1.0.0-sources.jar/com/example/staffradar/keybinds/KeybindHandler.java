package com.example.staffradar.keybinds;

import com.example.staffradar.gui.StaffOverlayUI;
import com.example.staffradar.gui.ConfigScreenUI;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;

public class KeybindHandler {
    private static class_304 toggleOverlayKey;
    private static class_304 openConfigKey;

    public static void register() {
        toggleOverlayKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.staffradar.toggle_overlay",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_V,
            "category.staffradar.main"
        ));

        openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.staffradar.open_config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_P,
            "category.staffradar.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleOverlayKey.method_1436()) {
                StaffOverlayUI.toggle();
            }
            while (openConfigKey.method_1436()) {
                ConfigScreenUI.open();
            }
        });
    }
}
