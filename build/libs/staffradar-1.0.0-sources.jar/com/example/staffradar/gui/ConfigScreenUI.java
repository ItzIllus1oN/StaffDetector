package com.example.staffradar.gui;

import com.example.staffradar.config.Config;
import com.example.staffradar.config.ConfigManager;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;

public class ConfigScreenUI extends class_437 {
    private class_342 keywordsField;
    private class_4286 keywordToggle;
    private class_4286 soundToggle;
    private class_4286 chunkToggle;
    private class_4286 alertToggle;
    private class_4286 blockToggle;
    private class_4286 particleToggle;
    private class_4286 invisibleEntityToggle;
    private class_4286 cameraToggle;

    public ConfigScreenUI() {
        super(class_2561.method_30163("StaffRadar Configuration"));
    }

    @Override
    protected void method_25426() {
        Config config = ConfigManager.getConfig();
        int leftX = this.field_22789 / 2 - 210;
        int rightX = this.field_22789 / 2 + 10;
        int startY = 35;
        int step = 22;

        // Left column
        this.keywordToggle = class_4286.method_54787(class_2561.method_30163("Keyword Detection"), this.field_22793)
            .method_54789(leftX, startY).method_54794(config.keywordEnabled).method_54788();
        this.method_37063(this.keywordToggle);

        this.soundToggle = class_4286.method_54787(class_2561.method_30163("Sound Detection"), this.field_22793)
            .method_54789(leftX, startY + step).method_54794(config.soundEnabled).method_54788();
        this.method_37063(this.soundToggle);

        this.chunkToggle = class_4286.method_54787(class_2561.method_30163("Chunk Resend Detection"), this.field_22793)
            .method_54789(leftX, startY + step * 2).method_54794(config.chunkEnabled).method_54788();
        this.method_37063(this.chunkToggle);

        this.blockToggle = class_4286.method_54787(class_2561.method_30163("Block Interaction Detection"), this.field_22793)
            .method_54789(leftX, startY + step * 3).method_54794(config.blockEnabled).method_54788();
        this.method_37063(this.blockToggle);

        // Right column
        this.particleToggle = class_4286.method_54787(class_2561.method_30163("Particle Detection"), this.field_22793)
            .method_54789(rightX, startY).method_54794(config.particleEnabled).method_54788();
        this.method_37063(this.particleToggle);

        this.invisibleEntityToggle = class_4286.method_54787(class_2561.method_30163("Invisible Entity Detection"), this.field_22793)
            .method_54789(rightX, startY + step).method_54794(config.invisibleEntityEnabled).method_54788();
        this.method_37063(this.invisibleEntityToggle);

        this.cameraToggle = class_4286.method_54787(class_2561.method_30163("Camera Aberration Detection"), this.field_22793)
            .method_54789(rightX, startY + step * 2).method_54794(config.cameraAberrationEnabled).method_54788();
        this.method_37063(this.cameraToggle);

        this.alertToggle = class_4286.method_54787(class_2561.method_30163("Staff Watch Alert"), this.field_22793)
            .method_54789(rightX, startY + step * 3).method_54794(config.spectatorAlertEnabled).method_54788();
        this.method_37063(this.alertToggle);

        // Keywords field
        int fieldY = startY + step * 4 + 10;
        this.keywordsField = new class_342(this.field_22793, this.field_22789 / 2 - 150, fieldY, 300, 20, class_2561.method_30163("Keywords"));
        this.keywordsField.method_1880(2000);
        this.keywordsField.method_1852(config.getKeywordsString());
        this.method_37063(this.keywordsField);

        // Save button
        this.method_37063(class_4185.method_46430(class_2561.method_30163("Save & Close"), button -> saveAndClose())
            .method_46434(this.field_22789 / 2 - 60, fieldY + 30, 120, 20).method_46431());
    }

    private void saveAndClose() {
        Config config = ConfigManager.getConfig();
        config.keywordEnabled = this.keywordToggle.method_20372();
        config.soundEnabled = this.soundToggle.method_20372();
        config.chunkEnabled = this.chunkToggle.method_20372();
        config.blockEnabled = this.blockToggle.method_20372();
        config.particleEnabled = this.particleToggle.method_20372();
        config.invisibleEntityEnabled = this.invisibleEntityToggle.method_20372();
        config.cameraAberrationEnabled = this.cameraToggle.method_20372();
        config.spectatorAlertEnabled = this.alertToggle.method_20372();
        config.setKeywordsFromString(this.keywordsField.method_1882());
        ConfigManager.save();
        this.method_25419();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xAA000000);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 15, 0xFFFFFF);
        int fieldLabelY = 35 + 22 * 4 + 10 - 12;
        context.method_25303(this.field_22793, "Staff Keywords (comma separated):", this.field_22789 / 2 - 150, fieldLabelY, 0xAAAAAA);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    public static void open() {
        class_310.method_1551().execute(() ->
            class_310.method_1551().method_1507(new ConfigScreenUI())
        );
    }
}
