package com.example.staffradar.gui;

import com.example.staffradar.StaffRadarMod;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class WatchAlertUI {
    private static long alertStartTime = 0;
    private static final long DURATION = 3000;

    public static void show() {
        alertStartTime = System.currentTimeMillis();
    }

    public static void renderHUD(class_332 context, float delta) {
        long now = System.currentTimeMillis();
        if (now - alertStartTime > DURATION) return;

        class_310 client = class_310.method_1551();
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        // Pulsing opacity
        float progress = (now - alertStartTime) / (float) DURATION;
        float opacity = (float) Math.sin(progress * Math.PI * 4) * 0.5f + 0.5f;
        int color = ((int) (opacity * 150) << 24) | 0xFF0000;

        // Draw red aura (border)
        context.method_25294(0, 0, screenWidth, 5, color);
        context.method_25294(0, screenHeight - 5, screenWidth, screenHeight, color);
        context.method_25294(0, 5, 5, screenHeight - 5, color);
        context.method_25294(screenWidth - 5, 5, screenWidth, screenHeight - 5, color);

        // Draw alert text
        String text = "⚠ STAFF IS WATCHING YOU ⚠";
        int textWidth = client.field_1772.method_1727(text);
        context.method_25303(client.field_1772, text, (screenWidth - textWidth) / 2, screenHeight / 2 - 20, 0xFF0000);
    }
}
