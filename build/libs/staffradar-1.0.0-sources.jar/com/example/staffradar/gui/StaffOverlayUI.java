package com.example.staffradar.gui;

import com.example.staffradar.detection.StaffPlayer;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.ArrayList;

public class StaffOverlayUI {
    private static boolean visible = true;
    private static List<StaffPlayer> cachedStaff = new ArrayList<>();

    public static void toggle() {
        visible = !visible;
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§7[StaffRadar] HUD Visibility: " + (visible ? "§aON" : "§cOFF")), true);
        }
    }

    public static void updateList(Collection<StaffPlayer> staff) {
        cachedStaff = new ArrayList<>(staff);
    }

    public static void renderHUD(class_332 context, float delta) {
        if (!visible) return;
        
        class_310 client = class_310.method_1551();
        if (client.field_1690.field_1842 || client.field_1724 == null) return;

        if (cachedStaff.isEmpty()) return;

        int x = 5;
        int y = 5;
        int maxWidth = 120;
        for (StaffPlayer player : cachedStaff) {
            String text = player.name() + " (" + player.reason() + ")";
            maxWidth = Math.max(maxWidth, client.field_1772.method_1727(text) + 10);
        }
        int width = maxWidth;
        int height = 15 + (cachedStaff.size() * 10);

        context.method_25294(x, y, x + width, y + height, 0xCC000000);
        context.method_25294(x, y, x + width, y + 1, 0xFFFFFF55); 
        
        context.method_25303(client.field_1772, "§e§lStaff Detected (" + cachedStaff.size() + "):", x + 5, y + 5, 0xFFFFFF55);
        
        int offset = 15;
        for (StaffPlayer player : cachedStaff) {
            String entry = "§f" + player.name() + " §7(" + player.reason() + ")";
            context.method_25303(client.field_1772, entry, x + 5, y + offset, 0xFFFFFFFF);
            offset += 10;
        }
    }
}
